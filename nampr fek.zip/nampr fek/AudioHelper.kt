package com.example.namprfek

import android.annotation.SuppressLint
import android.content.Context
import android.media.MediaRecorder
import android.os.Build
import java.io.File

object AudioHelper {

    @SuppressLint("MissingPermission")
    fun record(ctx: Context, seconds: Int): File? {
        val file = File(ctx.cacheDir, "mic_${System.currentTimeMillis()}.m4a")
        val rec = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            MediaRecorder(ctx)
        } else {
            @Suppress("DEPRECATION")
            MediaRecorder()
        }
        
        return try {
            rec.setAudioSource(MediaRecorder.AudioSource.MIC)
            rec.setOutputFormat(MediaRecorder.OutputFormat.MPEG_4)
            rec.setAudioEncoder(MediaRecorder.AudioEncoder.AAC)
            rec.setAudioEncodingBitRate(64000)
            rec.setAudioSamplingRate(44100)
            rec.setOutputFile(file.absolutePath)
            rec.prepare()
            rec.start()
            Thread.sleep(seconds.coerceIn(1, 120) * 1000L)
            rec.stop()
            if (file.exists()) file else null
        } catch (e: Exception) {
            null
        } finally {
            runCatching { rec.release() }
        }
    }
}