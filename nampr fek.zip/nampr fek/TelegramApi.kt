package com.example.namprfek

import okhttp3.*
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.RequestBody.Companion.asRequestBody
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.util.concurrent.TimeUnit

class TelegramApi(private val token: String) {
    private val client = OkHttpClient.Builder()
        .connectTimeout(20, TimeUnit.SECONDS)
        .readTimeout(40, TimeUnit.SECONDS)
        .build()
    private val base = "https://api.telegram.org/bot$token"
    private val json = "application/json".toMediaType()

    fun sendMessage(chatId: String, text: String) {
        val body = JSONObject().put("chat_id", chatId).put("text", text.take(4000)).toString().toRequestBody(json)
        val req = Request.Builder().url("$base/sendMessage").post(body).build()
        runCatching { client.newCall(req).execute().close() }
    }

    fun sendDocument(chatId: String, file: File, caption: String = "") {
        val body = MultipartBody.Builder().setType(MultipartBody.FORM)
            .addFormDataPart("chat_id", chatId)
            .addFormDataPart("caption", caption.take(1000))
            .addFormDataPart("document", file.name, file.asRequestBody("application/octet-stream".toMediaType()))
            .build()
        val req = Request.Builder().url("$base/sendDocument").post(body).build()
        runCatching { client.newCall(req).execute().close() }
    }

    fun getUpdates(offset: Long): JSONArray {
        val req = Request.Builder().url("$base/getUpdates?offset=$offset&timeout=25").get().build()
        return try {
            client.newCall(req).execute().use { r ->
                val b = r.body?.string() ?: return JSONArray()
                JSONObject(b).optJSONArray("result") ?: JSONArray()
            }
        } catch (e: Exception) { JSONArray() }
    }
}