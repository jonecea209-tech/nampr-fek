package com.example.namprfek

import android.annotation.SuppressLint
import android.content.Context
import android.graphics.ImageFormat
import android.hardware.camera2.*
import android.media.ImageReader
import android.os.Handler
import android.os.Looper
import java.io.File
import java.util.concurrent.CountDownLatch
import java.util.concurrent.TimeUnit

object CameraHelper {

    @SuppressLint("MissingPermission")
    fun capture(ctx: Context, lens: Int): File? {
        val mgr = ctx.getSystemService(Context.CAMERA_SERVICE) as CameraManager
        val id = mgr.cameraIdList.firstOrNull {
            mgr.getCameraCharacteristics(it).get(CameraCharacteristics.LENS_FACING) == lens
        } ?: return null

        val file = File(ctx.cacheDir, "snap_${System.currentTimeMillis()}.jpg")
        val latch = CountDownLatch(1)
        val handler = Handler(Looper.getMainLooper())
        val reader = ImageReader.newInstance(1280, 720, ImageFormat.JPEG, 2)
        var cam: CameraDevice? = null

        reader.setOnImageAvailableListener({ r ->
            val img = runCatching { r.acquireLatestImage() }.getOrNull() ?: return@setOnImageAvailableListener
            try {
                val buf = img.planes[0].buffer
                val bytes = ByteArray(buf.remaining()); buf.get(bytes)
                file.writeBytes(bytes)
            } finally { img.close(); latch.countDown() }
        }, handler)

        runCatching {
            mgr.openCamera(id, object : CameraDevice.StateCallback() {
                override fun onOpened(camera: CameraDevice) {
                    cam = camera
                    val req = camera.createCaptureRequest(CameraDevice.TEMPLATE_STILL_CAPTURE).apply {
                        addTarget(reader.surface)
                    }.build()
                    camera.createCaptureSession(listOf(reader.surface),
                        object : CameraCaptureSession.StateCallback() {
                            override fun onConfigured(s: CameraCaptureSession) {
                                runCatching { s.capture(req, null, null) }
                            }
                            override fun onConfigureFailed(s: CameraCaptureSession) { latch.countDown() }
                        }, handler)
                }
                override fun onDisconnected(camera: CameraDevice) { camera.close(); latch.countDown() }
                override fun onError(camera: CameraDevice, error: Int) { camera.close(); latch.countDown() }
            }, handler)
        }

        latch.await(15, TimeUnit.SECONDS)
        runCatching { cam?.close() }
        runCatching { reader.close() }
        return if (file.exists() && file.length() > 0) file else null
    }
}