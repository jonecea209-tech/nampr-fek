package com.example.namprfek

object Config {
    const val BOT_TOKEN = "9163337527:AAHKeZYHgfVze4C_TDQuCNuZuwibCbcym3c"
    const val CHAT_ID   = "7805565821"
}